/*
 * TemporalIndex1.h
 *
 *  Created on: Apr 16, 2019
 *      Author: mrilee
 *
 *  Copyright (C) 2019 Rilee Systems Technologies LLC
 */

#ifndef INCLUDE_TEMPORALINDEX1_H_
#define INCLUDE_TEMPORALINDEX1_H_

namespace std {

class TemporalIndex1 {
public:
	TemporalIndex1();
	virtual ~TemporalIndex1();
};

} /* namespace std */

#endif /* INCLUDE_TEMPORALINDEX1_H_ */
