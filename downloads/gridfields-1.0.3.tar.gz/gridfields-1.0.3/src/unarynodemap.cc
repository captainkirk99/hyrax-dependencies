
#include "config_gridfields.h"

#include "unarynodemap.h"

namespace GF {

class UnaryNodeMap;

} // namespace GF
