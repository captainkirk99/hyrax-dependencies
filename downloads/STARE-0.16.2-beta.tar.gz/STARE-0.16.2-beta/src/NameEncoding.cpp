/*
 * NameEncoding.C
 *
 *  Created on: Jan 23, 2016
 *      Author: mrilee
 */

#include "NameEncoding.h"

//NameEncoding::NameEncoding() {
//	// TODO Auto-generated constructor stub
//
//}

using namespace std;

NameEncoding::~NameEncoding() {
	// TODO Auto-generated destructor stub
}

