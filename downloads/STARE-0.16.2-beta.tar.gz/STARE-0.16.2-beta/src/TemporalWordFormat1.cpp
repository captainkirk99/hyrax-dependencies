/*
 * TemporalWordFormat1.cpp
 *
 *  Created on: Apr 16, 2019
 *      Author: mrilee
 *
 *  Copyright (C) 2019 Rilee Systems Technologies LLC
 */

#include "TemporalWordFormat1.h"

namespace std {

TemporalWordFormat1::TemporalWordFormat1() {
}

TemporalWordFormat1::~TemporalWordFormat1() {
  // for(auto it = begin(bitFields); it != end(bitFields); ++ it) {
  //   delete (*it);
  // }
}

}
