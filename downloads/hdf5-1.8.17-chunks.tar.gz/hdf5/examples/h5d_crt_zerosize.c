/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * Copyright by the Board of Trustees of the University of Illinois.         *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the files COPYING and Copyright.html.  COPYING can be found at the root   *
 * of the source code distribution tree; Copyright.html can be found at the  *
 * root level of an installed copy of the electronic HDF5 document set and   *
 * is linked from the top-level documents page.  It can also be found at     *
 * http://hdfgroup.org/HDF5/doc/Copyright.html.  If you do not have          *
 * access to either file, you may request a copy from help@hdfgroup.org.     *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 *  This example illustrates how to create a dataset that is a 4 x 6 
 *  array.  It is used in the HDF5 Tutorial.
 */

#include "hdf5.h"
#define FILE "dset_zerosize.h5"
#define dsetname1 "dint8_ch"
#define dsetname2 "duint8_ch"
#define dsetname3 "dint16_ch"
#define dsetname4 "duint16_ch"
#define dsetname5 "dint32_ch"
#define dsetname6 "duint32_ch"
#define dsetname7 "dint64_ch"
#define dsetname8 "duint64_ch"
#define dsetname9 "dfloat32_ch"
#define dsetname10 "dfloat64_ch"
#define dsetname11 "dint8_co"
#define dsetname12 "duint8_co"
#define dsetname13 "dint16_co"
#define dsetname14 "duint16_co"
#define dsetname15 "dint32_co"
#define dsetname16 "duint32_co"
#define dsetname17 "dint64_co"
#define dsetname18 "duint64_co"
#define dsetname19 "dfloat32_co"
#define dsetname20 "dfloat64_co"


int gen_zerosize_dset(hid_t file_id,char *dsetname,hid_t dtype_id,hid_t dspace_id,void* fvalue,short layout);

int main() {

   hid_t       file_id, dataset_id, dataspace_id;  /* identifiers */
   hid_t       dcpl = -1;
   hsize_t     dims[2];
   H5D_space_status_t  allocation;
   H5D_alloc_time_t    alloc_time;
   H5D_fill_time_t fill_time;
   int fill_ctype = 1;

   long long ll_fill_value = -2147483649;
   unsigned long long ull_fill_value = 4294967296;
   int int_fill_value = -2147483648;
   unsigned int uint_fill_value =  4294967295;
   short short_fill_value = -32768;
   unsigned short ushort_fill_value = 65535;
   uint8_t uint8_fill_value = 255;
   int8_t  int8_fill_value = 127;
   float float_fill_value = 999.0;
   double double_fill_value = -9999.0;

 
   herr_t      status;

   /* Create a new file using default properties. */
   file_id = H5Fcreate(FILE, H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);

   /* Create the data space for the dataset. */
   dims[0] = 4; 
   dims[1] = 4; 
   dataspace_id = H5Screate_simple(2, dims, NULL);

   gen_zerosize_dset(file_id,dsetname1,H5T_NATIVE_CHAR,dataspace_id,(void*)&int8_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname2,H5T_NATIVE_UCHAR,dataspace_id,(void*)&uint8_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname3,H5T_NATIVE_SHORT,dataspace_id,(void*)&short_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname4,H5T_NATIVE_USHORT,dataspace_id,(void*)&ushort_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname5,H5T_NATIVE_INT,dataspace_id,(void*)&int_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname6,H5T_NATIVE_UINT,dataspace_id,(void*)&uint_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname7,H5T_NATIVE_LLONG,dataspace_id,(void*)&ll_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname8,H5T_NATIVE_ULLONG,dataspace_id,(void*)&ull_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname9,H5T_NATIVE_FLOAT,dataspace_id,(void*)&float_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname10,H5T_NATIVE_DOUBLE,dataspace_id,(void*)&double_fill_value,H5D_CHUNKED);
   gen_zerosize_dset(file_id,dsetname11,H5T_NATIVE_CHAR,dataspace_id,(void*)&int8_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname12,H5T_NATIVE_UCHAR,dataspace_id,(void*)&uint8_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname13,H5T_NATIVE_SHORT,dataspace_id,(void*)&short_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname14,H5T_NATIVE_USHORT,dataspace_id,(void*)&ushort_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname15,H5T_NATIVE_INT,dataspace_id,(void*)&int_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname16,H5T_NATIVE_UINT,dataspace_id,(void*)&uint_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname17,H5T_NATIVE_LLONG,dataspace_id,(void*)&ll_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname18,H5T_NATIVE_ULLONG,dataspace_id,(void*)&ull_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname19,H5T_NATIVE_FLOAT,dataspace_id,(void*)&float_fill_value,H5D_CONTIGUOUS);
   gen_zerosize_dset(file_id,dsetname20,H5T_NATIVE_DOUBLE,dataspace_id,(void*)&double_fill_value,H5D_CONTIGUOUS);


   /* Terminate access to the data space. */ 
   status = H5Sclose(dataspace_id);

   /* Close the file. */
   status = H5Fclose(file_id);
}

int gen_zerosize_dset(hid_t file_id,char *dsetname,hid_t dtype_id, hid_t dspace_id, void* fvalue,short layout){

   hid_t       dataset_id = -1;
   hid_t       dcpl = -1;
   H5D_space_status_t  allocation;
   H5D_alloc_time_t    alloc_time;
   H5D_fill_time_t fill_time;
   hsize_t chunk_dims[2];
   herr_t      status;


   chunk_dims[0] = 2;
   chunk_dims[1] = 2;
   /* Create the data space for the dataset. */
   dcpl=H5Pcreate(H5P_DATASET_CREATE); 

   if(H5D_COMPACT!=layout) {

        if(H5D_CHUNKED == layout) {
            if(H5Pset_chunk(dcpl,2,chunk_dims) <0) {
                printf("cannot set chunk \n");
                return -1;
            }
        }


        if(H5Pset_alloc_time(dcpl, H5D_ALLOC_TIME_LATE) < 0) {
           printf("cannot allocate time \n");
           return -1;
        }
             
        if(H5Pset_fill_time(dcpl, H5D_FILL_TIME_ALLOC) < 0) {
           printf("cannot fill time \n");
           return -1;

        }

        if(H5Pset_fill_value(dcpl, dtype_id, fvalue) < 0){
            printf("cannot set fill value \n");
            return -1;
        }
   }
   /* Create the dataset. */
   dataset_id = H5Dcreate2(file_id, dsetname, dtype_id, dspace_id, 
                          H5P_DEFAULT, dcpl, H5P_DEFAULT);

   H5Pclose(dcpl);
   /* End access to the dataset and release resources used by it. */
   status = H5Dclose(dataset_id);




}

