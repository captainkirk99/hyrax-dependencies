/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * Copyright by the Board of Trustees of the University of Illinois.         *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the files COPYING and Copyright.html.  COPYING can be found at the root   *
 * of the source code distribution tree; Copyright.html can be found at the  *
 * root level of an installed copy of the electronic HDF5 document set and   *
 * is linked from the top-level documents page.  It can also be found at     *
 * http://hdfgroup.org/HDF5/doc/Copyright.html.  If you do not have          *
 * access to either file, you may request a copy from help@hdfgroup.org.     *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/****************/
/* Module Setup */
/****************/

#define H5D_PACKAGE		/*suppress error about including H5Dpkg	  */

/* Interface initialization */
#define H5_INTERFACE_INIT_FUNC	H5D__init_dbg_interface


/***********/
/* Headers */
/***********/
#include "H5private.h"		/* Generic Functions			*/
#include "H5Dpkg.h"		/* Datasets 				*/
#include "H5Eprivate.h"		/* Error handling		  	*/
#include "H5Iprivate.h"		/* IDs			  		*/


/****************/
/* Local Macros */
/****************/


/******************/
/* Local Typedefs */
/******************/


/********************/
/* Local Prototypes */
/********************/


/*********************/
/* Package Variables */
/*********************/


/*****************************/
/* Library Private Variables */
/*****************************/


/*******************/
/* Local Variables */
/*******************/


/*--------------------------------------------------------------------------
NAME
   H5D__init_dbg_interface -- Initialize interface-specific information
USAGE
    herr_t H5D__init_dbg_interface()
RETURNS
    Non-negative on success/Negative on failure
DESCRIPTION
    Initializes any interface-specific data or routines.  (Just calls
    H5D_init() currently).

--------------------------------------------------------------------------*/
static herr_t
H5D__init_dbg_interface(void)
{
    FUNC_ENTER_STATIC_NOERR

    FUNC_LEAVE_NOAPI(H5D_init())
} /* H5D__init_dbg_interface() */


/*-------------------------------------------------------------------------
 * Function:	H5Ddebug
 *
 * Purpose:	Prints various information about a dataset.  This function is
 *		not to be documented in the API at this time.
 *
 * Return:	Success:	Non-negative
 *
 *		Failure:	Negative
 *
 * Programmer:	Robb Matzke
 *              Wednesday, April 28, 1999
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5Ddebug(hid_t dset_id)
{
    H5D_t	*dset;                  /* Dataset to debug */
    herr_t      ret_value = SUCCEED;    /* Return value */

    FUNC_ENTER_API(FAIL)
    H5TRACE1("e", "i", dset_id);

    /* Check args */
    if(NULL == (dset = (H5D_t *)H5I_object_verify(dset_id, H5I_DATASET)))
	HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a dataset")

    /* Print B-tree information */
    if(H5D_CHUNKED == dset->shared->layout.type)
	(void)H5D__chunk_dump_index(dset, H5AC_ind_dxpl_id, stdout);
    else if(H5D_CONTIGUOUS == dset->shared->layout.type)
	HDfprintf(stdout, "    %-10s %a\n", "Address:", dset->shared->layout.storage.u.contig.addr);

done:
    FUNC_LEAVE_API(ret_value)
} /* end H5Ddebug() */


/*-------------------------------------------------------------------------
 * Function:	H5Dget_dataset_storage_info
 *
 * Purpose:	hacking function to obtain the HDF5 dataset layout and number of chunks
 *		
 *
 * Return:	Success:	Non-negative
 *
 *		Failure:	Negative
 *
 * Programmer:	Muqun Yang
 *              August 24, 2016
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5Dget_dataset_storage_info(hid_t dset_id,uint8_t* layout_typeptr,hsize_t* num_chunkptr,uint8_t* storage_status_ptr)
{
    H5D_t	*dset;                  /* Dataset to debug */
    herr_t      ret_value = SUCCEED;    /* Return value */
    uint8_t layout_type = 0;
    uint8_t storage_status = 1;

    FUNC_ENTER_API(FAIL)
    H5TRACE1("e", "i", dset_id);


    /* Check args */
    if(NULL == (dset = (H5D_t *)H5I_object_verify(dset_id, H5I_DATASET)))
		HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a dataset")

    if(H5Dget_storage_size(dset_id) == 0)
        storage_status = 0;


    
    /* Obtaining layout information */
    if(H5D_CHUNKED == dset->shared->layout.type) {
        layout_type = 2;
        *num_chunkptr = dset->shared->layout.u.chunk.nchunks;
    }
    else if(H5D_CONTIGUOUS == dset->shared->layout.type) 
        layout_type = 1;
    else if(H5D_COMPACT == dset->shared->layout.type)
        layout_type = 3;

    *layout_typeptr = layout_type;
    
    *storage_status_ptr = storage_status;

done:
    FUNC_LEAVE_API(ret_value)
} /* end H5Dget_dataset_storage_info() */

/*-------------------------------------------------------------------------
 * Function:	H5Dget_dataset_chunk_storage_info
 *
 * Purpose:	hacking function to obtain the chunking info of all chunks in an HDF5 dataset
 *		
 *
 * Return:	Success:	Non-negative
 *
 *		Failure:	Negative
 *
 * Programmer:	Muqun Yang
 *              August 24, 2016
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5Dget_dataset_chunk_storage_info(hid_t dset_id,H5D_chunk_storage_info_t chunk_st_array[],unsigned int *num_chunk_dims_ptr)
{
    H5D_t	*dset;                  /* Dataset to debug */
    herr_t      ret_value = SUCCEED;    /* Return value */
    int chunk_index = 0;

    FUNC_ENTER_API(FAIL)
    H5TRACE1("e", "i", dset_id);

    /* Check args */
    if(NULL == (dset = (H5D_t *)H5I_object_verify(dset_id, H5I_DATASET)))
	HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a dataset")

    *num_chunk_dims_ptr = dset->shared->layout.u.chunk.ndims;

    /* Obtaining layout information */
    if(H5D_CHUNKED == dset->shared->layout.type) {
	(void)H5D__chunk_get_storage_info(dset, H5AC_ind_dxpl_id, chunk_st_array,&chunk_index);
    }

done:
    FUNC_LEAVE_API(ret_value)
} /* end H5Dget_dataset_chunk_storage_info */

/*-------------------------------------------------------------------------
 * Function:	H5Dget_dataset_contiguous_storage_info
 *
 * Purpose:	hacking function to obtain the information of the contiguous_storage, offset and length
 *		
 *
 * Return:	Success:	Non-negative
 *
 *		Failure:	Negative
 *
 * Programmer:	Muqun Yang
 *              August 24, 2016
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5Dget_dataset_contiguous_storage_info(hid_t dset_id,haddr_t* addr_ptr,hsize_t* size_ptr)
{
    H5D_t	*dset;                  /* Dataset to debug */
    herr_t      ret_value = SUCCEED;    /* Return value */

    FUNC_ENTER_API(FAIL)
    H5TRACE1("e", "i", dset_id);

    /* Check args */
    if(NULL == (dset = (H5D_t *)H5I_object_verify(dset_id, H5I_DATASET)))
	HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a dataset")

    /* Obtaining layout information */
    if(H5D_CONTIGUOUS == dset->shared->layout.type) {
	*addr_ptr = dset->shared->layout.storage.u.contig.addr;
        *size_ptr = dset->shared->layout.storage.u.contig.size;
    }

done:
    FUNC_LEAVE_API(ret_value)
} /* end H5Dget_dataset_contiguous_storage_info */

/*-------------------------------------------------------------------------
 * Function:	H5Dget_dataset_compact_storage_info
 *
 * Purpose:	hacking function to obtain the information of the compact storage,  length
 *		
 *
 * Return:	Success:	Non-negative
 *
 *		Failure:	Negative
 *
 * Programmer:	Muqun Yang
 *              August 24, 2016
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5Dget_dataset_compact_storage_info(hid_t dset_id,size_t* size_ptr)
{
    H5D_t	*dset;                  /* Dataset to debug */
    herr_t      ret_value = SUCCEED;    /* Return value */

    FUNC_ENTER_API(FAIL)
    H5TRACE1("e", "i", dset_id);

    /* Check args */
    if(NULL == (dset = (H5D_t *)H5I_object_verify(dset_id, H5I_DATASET)))
	HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a dataset")

    /* Obtaining layout information */
    if(H5D_COMPACT == dset->shared->layout.type) {
        *size_ptr = dset->shared->layout.storage.u.compact.size;
    }

done:
    FUNC_LEAVE_API(ret_value)
} /* end H5Dget_dataset_compact_storage_info */


