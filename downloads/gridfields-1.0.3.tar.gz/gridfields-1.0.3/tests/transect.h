
#include <string>

using namespace std;
class GridFieldOperator;
class GridField;

GridField *getUserGrid(string fn);
void View(GridFieldOperator *op, string attr);

void VerticalSlice();

