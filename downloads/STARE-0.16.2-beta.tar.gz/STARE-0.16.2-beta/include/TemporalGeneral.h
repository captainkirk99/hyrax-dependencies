#include <vector>

struct Datetime {
	int year, month, day, hour, minute, second, ms;	
};

typedef std::vector<Datetime> DatetimeVector ; 
