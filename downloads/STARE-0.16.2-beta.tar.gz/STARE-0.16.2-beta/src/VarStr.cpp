
#include <VarStr.h>
#include <VarStr.hpp>
