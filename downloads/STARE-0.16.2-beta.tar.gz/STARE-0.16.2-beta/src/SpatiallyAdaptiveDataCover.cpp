/*
 * SpatiallyAdaptiveDataCover.C
 *
 *  Created on: Jan 20, 2017
 *      Author: mrilee
 */

#include "SpatiallyAdaptiveDataCover.h"

namespace std {

//

SpatiallyAdaptiveDataCover::SpatiallyAdaptiveDataCover() {
	// TODO Auto-generated constructor stub

}

SpatiallyAdaptiveDataCover::~SpatiallyAdaptiveDataCover() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */
