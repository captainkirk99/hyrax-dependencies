# CUTE
C++ Unit Testing Easier: A Header-only C++ unit testing framework

usually available as part of the Cevelop C++ IDE (http://cevelop.com)

Dependency with C++03: boost

free standing with C++11/14

Also available through Conan.io thanks to fmorgner: 

 * https://github.com/fmorgner/cute-conan
 * https://www.conan.io/source/CUTE/2.2.0/fmorgner/stable
