/*
 * TemporalIndex1.cpp
 *
 *  Created on: Apr 16, 2019
 *      Author: mrilee
 *
 *  Copyright (C) 2019 Rilee Systems Technologies LLC
 */

#include "TemporalIndex1.h"

namespace std {

TemporalIndex1::TemporalIndex1() {
	// TODO Auto-generated constructor stub

}

TemporalIndex1::~TemporalIndex1() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */
