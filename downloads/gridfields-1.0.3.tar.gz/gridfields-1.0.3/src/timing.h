#include <sys/times.h>
#include <unistd.h>
#include <stdlib.h>
float gettime();
