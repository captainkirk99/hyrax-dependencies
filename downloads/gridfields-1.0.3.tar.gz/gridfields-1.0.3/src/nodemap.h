#ifndef _NODEMAP_H
#define _NODEMAP_H

#include "type.h"

namespace GF {

class NodeMap {

 public:
 private:
};


} // namespace GF

#endif /* _NODEMAP_H */
