/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * Copyright by the Board of Trustees of the University of Illinois.         *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the files COPYING and Copyright.html.  COPYING can be found at the root   *
 * of the source code distribution tree; Copyright.html can be found at the  *
 * root level of an installed copy of the electronic HDF5 document set and   *
 * is linked from the top-level documents page.  It can also be found at     *
 * http://hdfgroup.org/HDF5/doc/Copyright.html.  If you do not have          *
 * access to either file, you may request a copy from help@hdfgroup.org.     *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 *   This program provides the storage information of an HDF5 chunking/contiguous dataset.
 *   For a chunked dataset, the number of chunks in an HDF5 dataset and the number of chunk dimensions, 
 *   the starting file address of a chunk, storage size of a chunk and the logical offset of this chunk are provided.
 *   For a contiguous dataset, the offset and the length of this HDF5 dataset are provided.
 */

#include "hdf5.h"
#include <stdlib.h>

/*
#define H5FILE_NAME        "tdset2c.h5"
#define DATASETNAME "dset1"
#define DATASETNAME2 "dset2"
*/


int
main (int argc, char*argv[])
{
    hid_t       file;                        /* handles */
    hid_t       dataset;

    /* Will be used to store the chunking info. */
    H5D_chunk_storage_info_t* chunk_st_ptr;
    herr_t      status;

    unsigned int num_chunk_dims = 0;

    if(argc !=3) {
        printf("Please provide the HDF5 file name and the HDF5 dataset name as the following:\n");
        printf(" ./h5dstoreinfo h5_file_name h5_dset_path .\n");
        return 0;
    }
    /*
     * Open the file and the dataset.
     */
    file = H5Fopen(argv[1], H5F_ACC_RDONLY, H5P_DEFAULT);
    if(file < 0) {
        printf("HDF5 file %s cannot be opened successfully,check the file name and try again.\n",argv[1]);
        return -1;
    }

    dataset = H5Dopen2(file, argv[2], H5P_DEFAULT);
    if(dataset < 0) {
        H5Fclose(file);
        printf("HDF5 dataset %s cannot be opened successfully,check the dataset path and try again.\n",argv[2]);
        return -1;
    }

    uint8_t layout_type = 0;
    uint8_t storage_status = 0;
    int num_chunk = 0;
    int i = 0;
    int j = 0;
   
    status = H5Dget_dataset_storage_info(dataset,&layout_type,(hsize_t*)&num_chunk,&storage_status);
    if(status < 0) {
        H5Dclose(dataset);
        H5Fclose(file);
        printf("Cannot get HDF5 dataset storage info. successfully.\n");
        return -1;
    }
    
  if(storage_status == 0) {
        
    hid_t dtype_id = H5Dget_type(dataset);
    if(dtype_id < 0) {
            H5Dclose(dataset);
            H5Fclose(file);
            printf("Cannot obtain the correct HDF5 datatype.\n");
            return -1;
    }
    if(H5Tget_class(dtype_id) == H5T_INTEGER || H5Tget_class(dtype_id) == H5T_FLOAT) {
        hid_t dcpl_id = H5Dget_create_plist(dataset);
        if(dcpl_id <0) {
            H5Dclose(dataset);
            H5Fclose(file);
            printf("Cannot obtain the HDF5 dataset creation property list.\n");
            return -1;
        }
        
        H5D_fill_value_t fvalue_status;
        if(H5Pfill_value_defined(dcpl_id,&fvalue_status)<0) {
            H5Pclose(dcpl_id);
            H5Dclose(dataset);
            H5Fclose(file);
            printf("Cannot obtain the fill value status.\n");
            return -1;
        }

        if(fvalue_status == H5D_FILL_VALUE_UNDEFINED) {
            if(layout_type == 1)
                printf(" The storage size is 0 and the storge type is contiguous.\n");
            else if(layout_type == 2) 
                printf(" The storage size is 0 and the storage type is chunking.\n");
            else if(layout_type == 3)
                printf(" The storage size is 0 and the storage type is compact.\n");
            printf(" The Fillvalue is undefined .\n");
 
        }
        else {

            if(layout_type == 1)
                printf(" The storage size is 0 and the storage type is contiguous.\n");
            else if(layout_type == 2) 
                printf(" The storage size is 0 and the storage type is chunking.\n");
            else if(layout_type == 3)
                printf(" The storage size is 0 and the storage type is compact.\n");
 
            char *fvalue = NULL;
            size_t  fv_size = H5Tget_size(dtype_id);
            if(fv_size == 1) 
                fvalue = malloc(1);
            else if(fv_size == 2)
                fvalue = malloc(2);
            else if(fv_size == 4)
                fvalue = malloc(4);
            else if(fv_size == 8)
                fvalue = malloc(8);

            if(fv_size <= 8) {
                if(H5Pget_fill_value(dcpl_id,dtype_id,(void*)fvalue) <0){
                        H5Pclose(dcpl_id);
                        H5Dclose(dataset);
                        H5Fclose(file);
                        printf("Cannot obtain the fill value status.\n");
                        return -1;
                }

                if(H5Tget_class(dtype_id) == H5T_INTEGER){

                    H5T_sign_t fv_sign = H5Tget_sign(dtype_id);
                    if(fv_size == 1) {
                        if(fv_sign == H5T_SGN_NONE) {
#if 0
                            unsigned char temp_fvalue = 0;
                             H5Pget_fill_value(dcpl_id,dtype_id,(void*)&temp_fvalue);
                            printf("coming to unsigne char \n");
                            //temp_fvalue = 0;
                            //printf("The fillvalue of this dataset is %u\n", temp_fvalue);
#endif
                            printf("This dataset's datatype is unsigned char ");
                            printf("and the fillvalue is %u\n", *((unsigned char*)fvalue));
                        }
                        else  {
                            printf("This dataset's datatype is char ");
                            printf("and the fillvalue is %d\n", *fvalue);
                        }
                    }
                    else if(fv_size == 2){
                        if(fv_sign == H5T_SGN_NONE) {
                            printf("This dataset's datatype is unsigned short ");
                            printf("and the fillvalue is %hu\n", *((unsigned short*)fvalue));
                        }
                        else {
                            printf("This dataset's datatype is short ");
                            printf("and the fillvalue is %hd\n", *((short*)fvalue));
                        }
                    }
                    else if(fv_size == 4){
                        if(fv_sign == H5T_SGN_NONE){
                            printf("This dataset's datatype is unsigned int ");
                            printf("and the fillvalue is %u\n", *((unsigned int*)fvalue));
                        }
                        else {
                           printf("This dataset's datatype is int ");
                            printf("and the fillvalue is %d\n", *((int*)fvalue));
                        }
                    }
                    else if(fv_size == 8){
                        if(fv_sign == H5T_SGN_NONE){
                          printf("This dataset's datatype is unsigned long long ");
                           printf("and the fillvalue is %llu\n", *((unsigned long long*)fvalue));
                        }
                        else{
                           printf("This dataset's datatype is long long ");
                            printf("and the fillvalue is %lld\n", *((long long *)fvalue));
                        }
                    }
                }
                if(H5Tget_class(dtype_id) == H5T_FLOAT){
                    if(fv_size == 4){
                            printf("This dataset's datatype is float ");
                            printf("and the fillvalue is %f\n", *((float*)fvalue));
                    }
                    else if(fv_size == 8){
                            printf("This dataset's datatype is double ");
                            printf("and the fillvalue is %lf\n", *((double*)fvalue));
                    }
                }


                if(fvalue !=NULL)
                    free(fvalue);


            }
            else 
			  printf("The size of the datatype is greater than 8 bytes, Use HDF5 API H5Pget_fill_value() to retrieve the fill value of this dataset.\n");

        }
        H5Pclose(dcpl_id);
       
    }
    else {
        if(layout_type == 1)
            printf(" The storage size is 0 and the storage type is contiguous.\n");
        else if(layout_type == 2) 
            printf(" The storage size is 0 and the storage type is chunking.\n");
        else if(layout_type == 3)
            printf(" The storage size is 0 and the storage type is compact.\n");
 
        printf("The datatype is neither float nor integer,use HDF5 API H5Pget_fill_value() to retrieve the fill value of this dataset.\n");

    }

  }

  else {
    /* layout_type:  1 contiguous 2 chunk 3 compact */
    if(layout_type == 1) {/* Contiguous storage */
        haddr_t cont_addr = 0;
        hsize_t cont_size = 0;
        printf("Storage: contiguous\n");
        if(H5Dget_dataset_contiguous_storage_info(dataset,&cont_addr,&cont_size) <0) {
            H5Dclose(dataset);
            H5Fclose(file);
            printf("Cannot obtain the contiguous storage info.\n");
            return -1;
        }
        printf("    Addr: %llu\n",cont_addr);
        printf("    Size: %llu\n",cont_size);
   
    }
    else if(layout_type == 2) {/*chunking storage */
        printf("storage: chunked.\n");
        printf("   Number of chunks is %d\n",num_chunk);
       
        /* Allocate the memory for the struct to obtain the chunk storage information */
        chunk_st_ptr=(H5D_chunk_storage_info_t*)calloc(num_chunk,sizeof(H5D_chunk_storage_info_t));
        if(!chunk_st_ptr) {
            H5Dclose(dataset);
            H5Fclose(file);
            printf("Cannot allocate the memory to store the chunked storage info.\n");
            return -1;
        }

        if(H5Dget_dataset_chunk_storage_info(dataset,chunk_st_ptr,&num_chunk_dims)<0) {
            H5Dclose(dataset);
            H5Fclose(file);
            printf("Cannot get HDF5 chunk storage info. successfully.\n");
            return -1;
        }

        printf("   Number of dimensions in a chunk is  %u\n",num_chunk_dims -1);
        for(i =0; i <num_chunk;i++){
            printf("    Chunk index:  %d\n",i);
            printf("      Number of bytes:  %u\n",chunk_st_ptr[i].nbytes);
            printf("      Logical offset: offset");
            for (j=0; j<num_chunk_dims -1; j++) 
                printf("[%llu]",chunk_st_ptr[i].chunk_offset[j]);
            printf("\n");
            printf("      Physical offset: %llu\n",chunk_st_ptr[i].chunk_addr); 
        }
        free(chunk_st_ptr);
    }
    else if(layout_type == 3) {/* Compact storage */
        printf("Storage: compact\n");
        size_t comp_size =0;
        if(H5Dget_dataset_compact_storage_info(dataset,&comp_size) <0) {
            H5Dclose(dataset);
            H5Fclose(file);
            printf("Cannot obtain the compact storage info.\n");
            return -1;
        }
        printf("   Size: %lu\n", comp_size);
 
    }
   }
    H5Dclose(dataset);
    H5Fclose(file);

    return 0;
}
