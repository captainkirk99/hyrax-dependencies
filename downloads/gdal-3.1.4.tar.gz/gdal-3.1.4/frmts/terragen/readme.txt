Terragen(tm) GDAL Driver 1.2
Copyright 2006-2007 Daylon Graphics Ltd.
Support: support@daylongraphics.com


This is a GDAL driver for Terragen heightfield files.

...

For more information on Terragen, please visit
the Planetside website at
http://www.planetside.co.uk/terragen


